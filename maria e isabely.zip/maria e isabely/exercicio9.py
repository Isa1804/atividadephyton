def media(a,b):
    s = a + b
    m = s / 2
    return m

a = float(input("insira um numero: "))
b = float(input("insira outro numero: "))
print(f"A media de {a} e {b} é: {media(a,b)}")